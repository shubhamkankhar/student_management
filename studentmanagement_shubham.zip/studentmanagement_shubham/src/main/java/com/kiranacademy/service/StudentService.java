package com.kiranacademy.service;
import java.util.ArrayList;

import com.kiranacademy.dao.StudentDao;
import com.kiranacademy.student.Student;

public class StudentService {
	public static ArrayList<Student> fetchStudent() throws Exception{
		ArrayList<Student> alStu=StudentDao.fetchStudent();
		ArrayList<Student> alStuFiltered =StudentDao.fetchStudent();
		for (Student student : alStu) {
			if(!student.sname.startsWith("K")) {
				
				alStuFiltered.add(student);
			}
		}
		
		return alStuFiltered;
		
	}

}
