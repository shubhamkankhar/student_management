package com.kiranacademy.controller;
import java.util.ArrayList;

import com.kiranacademy.dao.StudentDao;
import com.kiranacademy.student.Student;
public class StudentController {
	ArrayList<Student> fetchStudent() throws Exception{
	ArrayList<Student> alStu=StudentDao.fetchStudent();
			
		return null;
			
			
	}
	}



