package com.kiranacademy.utility;
import java.util.ArrayList;
import com.kiranacademy.service.StudentService;
import com.kiranacademy.student.Student;

public class DBUtility {
	public static void main(String[] args) throws Exception {
		ArrayList<Student> al=StudentService.fetchStudent();
		
		for (Student student : al) {
			System.out.println(student.sid);
			System.out.println(student.sname);
		}
	}

}
