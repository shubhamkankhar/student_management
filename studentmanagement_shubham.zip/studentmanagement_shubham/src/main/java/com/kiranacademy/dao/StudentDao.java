package com.kiranacademy.dao;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.kiranacademy.student.Student;
public class StudentDao {
	public static ArrayList<Student> fetchStudent() throws Exception{
		
		//System.out.println(1);
		Class.forName("com.mysql.jdbc.Driver");
		//System.out.println(2);
		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/advance","root","root");
		//System.out.println(3);
		String sql="Select * from student1";
		//System.out.println(4);
		Statement statement=connection.createStatement();
		//System.out.println(5);
		ResultSet resultSet=statement.executeQuery(sql);
		ArrayList<Student>alStu=new ArrayList<Student>();
		while(resultSet.next()) {
			int sid=resultSet.getInt(1);
			String sname=resultSet.getString(2);
			Student student=new Student(sid,sname);
			alStu.add(student);
			//System.out.println("Stud_ID: "+sid);
			//System.out.println("Stud_NM: "+sname);
			
		}
		
		
		
		return alStu;
		
		
	}

}
